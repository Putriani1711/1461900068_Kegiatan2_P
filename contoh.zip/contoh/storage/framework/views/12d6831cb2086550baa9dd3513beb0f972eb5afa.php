<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Show Data Buku</div>

                <div class="panel-body">
                    <div class="col-md-10">
                        <div class="box box-primary">
                        <!-- /.box-header -->
                        <form action="#" method="POST" enctype="multipart/form-data" >
                            <div class="box-body">
                                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                <div class="form-group">
                                    <div class="row"> 
                                        <div class="col-xs-12">
                                            <label for="">Judul Buku</label>
                                            <input type="text" class="form-control" value="<?php echo e($item->buku_judul); ?>" name="buku_judul">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-xs-6">
                                            <label for="exampleInputEmail1">Kategori</label>
                                            <input class="form-control" value="<?php echo e($item->kategori_nama); ?>">
                                        </div>
                                        <div class="col-xs-6">
                                            <label for="">Jumlah Buku</label>
                                            <input type="text" class="form-control" value="<?php echo e($item->buku_jumlah); ?>" name="" >
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <label for="exampleInputEmail1">Deskripsi</label>
                                            <textarea  class="form-control"  name="" id="" cols="30" rows="10"><?php echo e($item->buku_deskripsi); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>