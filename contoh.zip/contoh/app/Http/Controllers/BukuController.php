<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BukuController extends Controller
{
    
    public function buku()
    {
        // mengambil data dari table petugas
        $buku = DB::table('buku')
                ->leftjoin('kategori', 'buku.buku_id', '=', 'kategori.kategori_id')
                ->select('buku.*', 'buku.kategori_id', 'buku.buku_judul','kategori.kategori_nama')
                ->get();
        // mengirim data pegawai ke view index
        return view('0068buku',['buku' => $buku]);
    }

    public function show_buku($id)
    {
        // mengambil data dari table petugas
        $buku = DB::table('buku')
                ->leftjoin('kategori', 'buku.buku_id', '=', 'kategori.kategori_id')
                ->select('buku.*', 'buku.kategori_id', 'buku.buku_judul','kategori.kategori_nama')
                ->where('buku.buku_id', $id)
                ->get();
        // mengirim data pegawai ke view index
        return view('0068showbuku',['buku' => $buku]);
    }

    public function kategori()
    {
        // mengambil data dari table petugas
        $kategori = DB::table('kategori')->get();
        // mengirim data pegawai ke view index
        return view('0068kategori',['kategori' => $kategori]);
    }

}
