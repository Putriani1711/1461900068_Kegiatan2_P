<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DataController extends Controller
{
    
    public function petugas()
    {
        // mengambil data dari table petugas
        $petugas = DB::table('petugas')->get();
        // mengirim data pegawai ke view index
        return view('0068petugas',['petugas' => $petugas]);
    }

    public function anggota()
    {
        // mengambil data dari table petugas
        $anggota = DB::table('anggota')->get();
        // mengirim data pegawai ke view index
        return view('0068anggota',['anggota' => $anggota]);
    }
}
