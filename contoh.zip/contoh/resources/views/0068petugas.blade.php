@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Data Petugas</div>

                <div class="panel-body">
                   <table class="table">
                       <tr>
                           <th>No</th>
                           <th>Nama</th>
                           <th>Username</th>
                       </tr>
                       <tr>
                           @php
                               $no = 1;
                           @endphp
                           @foreach ($petugas as $item)   
                           <td>{{ $no }}</td>
                           <td>{{ $item->petugas_nama }}</td>
                           <td>{{ $item->username }}</td>
                           @php
                               $no++;
                           @endphp
                           @endforeach
                       </tr>
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
