@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Show Data Buku</div>

                <div class="panel-body">
                    <div class="col-md-10">
                        <div class="box box-primary">
                        <!-- /.box-header -->
                        <form action="#" method="POST" enctype="multipart/form-data" >
                            <div class="box-body">
                                @foreach ($buku as $item)   
                                <div class="form-group">
                                    <div class="row"> 
                                        <div class="col-xs-12">
                                            <label for="">Judul Buku</label>
                                            <input type="text" class="form-control" value="{{ $item->buku_judul}}" name="buku_judul">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-xs-6">
                                            <label for="exampleInputEmail1">Kategori</label>
                                            <input class="form-control" value="{{ $item->kategori_nama }}">
                                        </div>
                                        <div class="col-xs-6">
                                            <label for="">Jumlah Buku</label>
                                            <input type="text" class="form-control" value="{{ $item->buku_jumlah }}" name="" >
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <label for="exampleInputEmail1">Deskripsi</label>
                                            <textarea  class="form-control"  name="" id="" cols="30" rows="10">{{ $item->buku_deskripsi }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection