@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Data Petugas</div>

                <div class="panel-body">
                   <table class="table">
                       <tr>
                           <th>No</th>
                           <th>Nama</th>
                           <th>Anggota Alamat</th>
                           <th>Jenis Kelamain</th>
                           <th>Telpon</th>
                       </tr>
                       <tr>
                           @php
                               $no = 1;
                           @endphp
                           @foreach ($anggota as $item)   
                           <td>{{ $no }}</td>
                           <td>{{ $item->anggota_nama }}</td>
                           <td>{{ $item->anggota_alamat }}</td>
                           <td>{{ $item->anggota_jk }}</td>
                           <td>{{ $item->anggota_telp }}</td>
                         
                       </tr>
                            @php
                                $no++;
                            @endphp
                            @endforeach
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
