@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Data Buku</div>

                <div class="panel-body">
                   <table class="table">
                       <tr>
                           <th>No</th>
                           <th>Nama Kategori</th>
                           <th>Judul Buku</th>
                           <th>Buku Jumlah</th>
                           <th>Show</th>
                       </tr>
                       <tr>
                           @php
                               $no = 1;
                           @endphp
                           @foreach ($buku as $item)   
                           <td>{{ $no }}</td>
                           <td>{{ $item->kategori_nama }}</td>
                           <td>{{ $item->buku_judul }}</td>
                           <td>{{ $item->buku_jumlah }}</td>
                           <td>
                                <a href="{{ url('show_buku')}}/{{ $item->buku_id }}" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i>Show </a>
                            </td>
                       </tr>
                            @php
                                $no++;
                            @endphp
                            @endforeach
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
