@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Data Petugas</div>

                <div class="panel-body">
                   <table class="table">
                       <tr>
                           <th>No</th>
                           <th>Nama</th>
                       </tr>
                       <tr>
                           @php
                               $no = 1;
                           @endphp
                           @foreach ($kategori as $item)   
                           <td>{{ $no }}</td>
                           <td>{{ $item->kategori_nama }}</td>
                       </tr>
                            @php
                                $no++;
                            @endphp
                            @endforeach
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
