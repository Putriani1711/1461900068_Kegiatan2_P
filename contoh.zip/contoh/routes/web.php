<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'DataController@petugas')->name('petugas');
Route::get('/anggota', 'DataController@anggota')->name('anggota');
Route::get('/kategori', 'BukuController@kategori')->name('kategori');
Route::get('/buku', 'BukuController@buku')->name('buku');
Route::get('/show_buku/{id}', 'BukuController@show_buku')->name('show_buku');

Auth::routes();
